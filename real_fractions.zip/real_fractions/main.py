from .convert import ConvertFractions
from .operation import OperationFractions

convert = ConvertFractions()
test = convert.to_fraction("1 -1/2")
print(test)
