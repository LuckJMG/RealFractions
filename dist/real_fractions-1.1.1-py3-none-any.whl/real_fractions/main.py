from .convert import ConvertFractions
from .operation import OperationFractions

operation = OperationFractions()
test = operation.root("-1/16", 4)
print(test)
