from .convert import ConvertFractions
from .operation import OperationFractions

operation = OperationFractions()
test = operation.division("3/2", 0)
print(test)
